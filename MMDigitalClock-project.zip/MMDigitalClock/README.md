# MM Digital Clock

Landscape fullscreen Android digital clock inspired by the reference image.

## Included
- Large green seven-segment clock with seconds
- AM/PM and 12/24-hour toggle (tap the clock)
- English weekday and Gregorian date
- Myanmar calendar year/month/day + moon phase
- Screen stays awake
- No internet permission
- Android 6.0+ (API 23+)

## Build
Open this folder in Android Studio and choose **Build > Build APK(s)**.
The project uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21.

The Myanmar calendar calculation is implemented locally for the modern Myanmar calendar era (1312 ME onward), based on the published Myanmar calendrical calculation method by Dr. Yan Naing Aye.
