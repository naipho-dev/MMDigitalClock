package com.jryan.mmdigitalclock

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.Window
import android.view.WindowManager
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.floor
import kotlin.math.roundToInt

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )
        setContentView(ClockView(this))
    }
}

private data class MyanmarDate(
    val year: Int, val month: Int, val day: Int, val moonPhase: String,
    val fortnightDay: Int, val weekday: Int, val monthType: Int
)

private object MyanmarCalendar {
    private const val SY = 1577917828.0 / 4320000.0
    private const val LM = 1577917828.0 / 53433336.0
    private const val MO = 1954168.050623
    private const val WO = -0.5
    private val monthNames = arrayOf("ဝါဆို", "တန်ခူး", "ကဆုန်", "နယုန်", "ဝါဆို", "ဝါခေါင်", "တော်သလင်း", "သီတင်းကျွတ်", "တန်ဆောင်မုန်း", "နတ်တော်", "ပြာသို", "တပို့တွဲ", "တပေါင်း")

    fun convert(y: Int, m: Int, d: Int): MyanmarDate {
        val jdn = gregorianToJdn(y, m, d)
        val my = floor((jdn - 0.5 - MO) / SY).toInt()
        val yo = chkMy(my)
        var dd = jdn - yo.tg1 + 1
        val b = floor(yo.myt / 2.0).toInt()
        val c = floor(1.0 / (yo.myt + 1.0)).toInt()
        val myl = 354 + (1 - c) * 30 + b
        val mmt = floor((dd - 1) / myl.toDouble()).toInt()
        dd -= mmt * myl
        val a = floor((dd + 423) / 512.0).toInt()
        var mm = floor((dd - b * a + c * a * 30 + 29.26) / 29.544).toInt()
        val e = floor((mm + 12) / 16.0).toInt()
        val f = floor((mm + 11) / 16.0).toInt()
        val md = dd - floor(29.544 * mm - 29.26).toInt() - b * e + c * f * 30
        mm += f * 3 - e * 4
        var mml = 30 - mm % 2
        if (mm == 3) mml += b
        val mp = floor((md + 1) / 16.0).toInt() + floor(md / 16.0).toInt() + floor(md / mml.toDouble()).toInt()
        val fd = md - 15 * floor(md / 16.0).toInt()
        val phase = when (mp) { 0 -> "လဆန်း"; 1 -> "လပြည့်"; 2 -> "လပြည့်ကျော်"; else -> "လကွယ်" }
        return MyanmarDate(my, mm, md, phase, fd, (jdn + 2) % 7, mmt)
    }

    fun monthName(mm: Int): String = when (mm) {
        0 -> monthNames[0]
        in 1..12 -> monthNames[mm]
        else -> ""
    }

    private data class YearInfo(val myt: Int, val tg1: Int, val fm: Int)
    private data class Watat(val fm: Int, val watat: Int)

    private fun chkWatat(my: Int): Watat {
        val nm = 8.0
        val ta = (SY / 12.0 - LM) * (12.0 - nm)
        var ed = (SY * (my + 3739)) % LM
        if (ed < ta) ed += LM
        var fm = (SY * my + MO - ed + 4.5 * LM + WO).roundToInt()
        var watat = if (ed >= LM - (SY / 12.0 - LM) * nm) 1 else 0
        if (my == 1344) watat = 1
        if (my == 1345) watat = 0
        if (my == 1377) fm += 1
        return Watat(fm, watat)
    }

    private fun chkMy(my: Int): YearInfo {
        var yd = 0
        var y1: Watat
        val y2 = chkWatat(my)
        var myt = y2.watat
        do { yd++; y1 = chkWatat(my - yd) } while (y1.watat == 0 && yd < 3)
        var fm: Int
        if (myt != 0) {
            val nd = (y2.fm - y1.fm) % 354
            myt = floor(nd / 31.0).toInt() + 1
            fm = y2.fm
        } else fm = y1.fm + 354 * yd
        val tg1 = y1.fm + 354 * yd - 102
        return YearInfo(myt, tg1, fm)
    }

    private fun gregorianToJdn(y: Int, m: Int, d: Int): Int {
        val a = (14 - m) / 12
        val yy = y + 4800 - a
        val mm = m + 12 * a - 3
        return d + (153 * mm + 2) / 5 + 365 * yy + yy / 4 - yy / 100 + yy / 400 - 32045
    }
}

private class ClockView(context: android.content.Context) : View(context) {
    private val handler = Handler(Looper.getMainLooper())
    private var use24 = false
    private val green = android.graphics.Color.rgb(52, 255, 132)
    private val yellow = android.graphics.Color.rgb(255, 220, 45)
    private val white = android.graphics.Color.rgb(238, 242, 246)
    private val gray = android.graphics.Color.rgb(95, 100, 105)
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val segmentPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val cal = Calendar.getInstance()

    init {
        paint.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        segmentPaint.color = green
        segmentPaint.setShadowLayer(18f, 0f, 0f, green)
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        handler.post(tick)
    }

    private val tick = object : Runnable {
        override fun run() { invalidate(); handler.postDelayed(this, 500L) }
    }

    override fun onDetachedFromWindow() { handler.removeCallbacksAndMessages(null); super.onDetachedFromWindow() }

    override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
        if (event.action == android.view.MotionEvent.ACTION_UP) { use24 = !use24; invalidate(); return true }
        return true
    }

    override fun onDraw(c: android.graphics.Canvas) {
        super.onDraw(c)
        c.drawColor(android.graphics.Color.BLACK)
        cal.time = Date()
        val w = width.toFloat(); val h = height.toFloat()
        val sec = cal.get(Calendar.SECOND)
        val min = cal.get(Calendar.MINUTE)
        val hr24 = cal.get(Calendar.HOUR_OF_DAY)
        val hr = if (use24) hr24 else ((hr24 + 11) % 12) + 1
        val ampm = if (hr24 < 12) "AM" else "PM"
        val dateY = cal.get(Calendar.YEAR); val dateM = cal.get(Calendar.MONTH) + 1; val dateD = cal.get(Calendar.DAY_OF_MONTH)
        val md = MyanmarCalendar.convert(dateY, dateM, dateD)

        val top = h * 0.055f
        drawSettings(c, 34f, top + 10f)
        drawBattery(c, w - 110f, top + 13f)

        val time = "%02d:%02d".format(Locale.US, hr, min)
        val digitH = h * 0.40f
        val digitW = digitH * 0.52f
        val gap = digitW * 0.10f
        val total = digitW * 4 + gap * 3 + digitW * 0.34f
        val startX = (w - total) / 2f
        val y = top + h * 0.035f
        drawDigit(c, startX, y, digitW, digitH, time[0] - '0')
        drawDigit(c, startX + digitW + gap, y, digitW, digitH, time[1] - '0')
        drawColon(c, startX + digitW * 2 + gap * 1.25f, y + digitH * 0.28f, digitH * 0.11f)
        drawDigit(c, startX + digitW * 2 + gap * 2.0f, y, digitW, digitH, time[3] - '0')
        drawDigit(c, startX + digitW * 3 + gap * 3.0f, y, digitW, digitH, time[4] - '0')

        paint.color = green; paint.textSize = h * 0.065f; paint.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText(if (use24) "24H" else ampm, startX - 5f, y + digitH * 0.90f, paint)
        val centerX = w / 2f
        c.drawText(weekdayName(cal.get(Calendar.DAY_OF_WEEK)), centerX - paint.measureText(weekdayName(cal.get(Calendar.DAY_OF_WEEK))) / 2, y + digitH + h * 0.035f, paint)
        val greg = "%02d/%02d/%04d".format(Locale.US, dateD, dateM, dateY)
        c.drawText(greg, w - 260f, y + digitH + h * 0.035f, paint)

        val lineY = h * 0.60f
        paint.color = gray; paint.strokeWidth = 1f; c.drawLine(28f, lineY, w - 28f, lineY, paint)
        c.drawLine(w * .235f, lineY + 18f, w * .235f, h - 58f, paint)
        c.drawLine(w * .50f, lineY + 18f, w * .50f, h - 58f, paint)
        c.drawLine(w * .765f, lineY + 18f, w * .765f, h - 58f, paint)

        drawBlock(c, w * .12f, lineY + 55f, "အင်္ဂလိပ်ရက်စွဲ", greg, green)
        val mmName = MyanmarCalendar.monthName(md.month)
        val myText = toMm(md.year)
        val dayText = toMm(md.day)
        drawBlock(c, w * .365f, lineY + 55f, "မြန်မာရက်စွဲ", "$mmName ${md.moonPhase} $dayText ရက်", yellow)
        paint.color = white; paint.textSize = h * .026f; paint.typeface = android.graphics.Typeface.DEFAULT
        c.drawText("မြန်မာနှစ် $myText ခု", w * .365f, lineY + 122f, paint)
        c.drawText("သာသနာနှစ် ${toMm(md.year + 544)} ခု", w * .365f, lineY + 153f, paint)

        drawBlock(c, w * .62f, lineY + 55f, "လဆန်း / လပြည့် / လဆုတ်", "${md.moonPhase} ${toMm(md.fortnightDay)} ရက်", green)
        drawBlock(c, w * .855f, lineY + 55f, "နေ့", burmeseWeekday(md.weekday), green)

        paint.color = white; paint.textSize = h * .022f
        c.drawText("12h / 24h  •  Screen Always On", 34f, h - 22f, paint)
        c.drawText("မြန်မာ Digital Clock", w - 220f, h - 22f, paint)
    }

    private fun drawBlock(c: android.graphics.Canvas, x: Float, y: Float, title: String, value: String, valueColor: Int) {
        paint.color = white; paint.textSize = height * .024f; paint.typeface = android.graphics.Typeface.DEFAULT
        c.drawText(title, x - 75f, y, paint)
        paint.color = valueColor; paint.textSize = height * .029f; paint.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText(value, x - 75f, y + 42f, paint)
    }

    private fun drawSettings(c: android.graphics.Canvas, x: Float, y: Float) {
        paint.style = android.graphics.Paint.Style.STROKE; paint.strokeWidth = 3f; paint.color = white
        c.drawCircle(x + 22, y + 22, 9f, paint); c.drawCircle(x + 22, y + 22, 17f, paint)
        paint.style = android.graphics.Paint.Style.FILL
        for (i in 0 until 8) { val a = i * Math.PI / 4; c.drawCircle(x + 22 + (Math.cos(a)*22).toFloat(), y + 22 + (Math.sin(a)*22).toFloat(), 3f, paint) }
    }
    private fun drawBattery(c: android.graphics.Canvas, x: Float, y: Float) {
        paint.style = android.graphics.Paint.Style.STROKE; paint.strokeWidth = 3f; paint.color = green
        c.drawRoundRect(x, y, x + 44, y + 21, 4f, 4f, paint); paint.style = android.graphics.Paint.Style.FILL
        c.drawRect(x + 47, y + 6, x + 51, y + 15, paint); c.drawRect(x + 4, y + 4, x + 37, y + 17, paint)
        paint.color = white; paint.textSize = 18f; c.drawText("60%", x + 62, y + 17, paint)
    }
    private fun drawColon(c: android.graphics.Canvas, x: Float, y: Float, r: Float) { segmentPaint.color = green; c.drawCircle(x, y, r, segmentPaint); c.drawCircle(x, y + r*3.1f, r, segmentPaint) }
    private fun drawDigit(c: android.graphics.Canvas, x: Float, y: Float, w: Float, h: Float, d: Int) {
        val t = w * .13f; val v = h * .39f
        val seg = arrayOf(
            android.graphics.RectF(x+t, y, x+w-t, y+t),
            android.graphics.RectF(x+w-t, y+t, x+w, y+v-t/2),
            android.graphics.RectF(x+w-t, y+v+t/2, x+w, y+h-v),
            android.graphics.RectF(x+t, y+h-t, x+w-t, y+h),
            android.graphics.RectF(x, y+v+t/2, x+t, y+h-v),
            android.graphics.RectF(x, y+t, x+t, y+v-t/2),
            android.graphics.RectF(x+t, y+h/2-t/2, x+w-t, y+h/2+t/2)
        )
        val map = intArrayOf(0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F)
        for (i in 0..6) if ((map[d] and (1 shl i)) != 0) c.drawRoundRect(seg[i], t/3, t/3, segmentPaint)
    }
    private fun weekdayName(d: Int) = arrayOf("", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")[d]
    private fun burmeseWeekday(wd: Int) = arrayOf("စနေ", "တနင်္ဂနွေ", "တနင်္လာ", "အင်္ဂါ", "ဗုဒ္ဓဟူး", "ကြာသပတေး", "သောကြာ")[wd]
    private fun toMm(n: Int): String { val a="၀၁၂၃၄၅၆၇၈၉"; return n.toString().map { a[it-'0'] }.joinToString("") }
}
